package com.nicolefrancesmeneses.calculator;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("ShowToast")
public class MainActivity extends Activity {
	
	TextView LCD;
	Button btndeci;
	int Operation=0,
		Ans=0;
	float Fnum=0,
		  Snum=0,
		  Answer=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		LCD = (TextView)findViewById(R.id.CalDisplay);
		btndeci = (Button)findViewById(R.id.btnDecimal);
	}
	
	//button #0
	public void B0(View v) {
		LCD.setText(LCD.getText().toString() + "0");
	}
	
	//button #1
	public void B1(View v) {
		LCD.setText(LCD.getText().toString() + "1");
	}
	
	//button #2
	public void B2(View v) {
		LCD.setText(LCD.getText().toString() + "2");
	}
	
	//button #3
	public void B3(View v) {
		LCD.setText(LCD.getText().toString() + "3");
	}
	
	//button #4
	public void B4(View v) {
		LCD.setText(LCD.getText().toString() + "4");
	}
	
	//button #5
	public void B5(View v) {
		LCD.setText(LCD.getText().toString() + "5");
	}
	
	//button #6
	public void B6(View v) {
		LCD.setText(LCD.getText().toString() + "6");
	}
	
	//button #7
	public void B7(View v) {
		LCD.setText(LCD.getText().toString() + "7");
	}
	
	//button #8
	public void B8(View v) {
		LCD.setText(LCD.getText().toString() + "8");
	}
	
	//button #9
	public void B9(View v) {
		LCD.setText(LCD.getText().toString() + "9");
	}
	
	//button clear
		public void Clear(View v) {
			LCD.setText(null);
		}

	//button decimal
		public void Decimal(View v) {
			LCD.setText(LCD.getText().toString() + ".");
		}

	//button addition
		public void Add(View v) {
			Operation = 1;
			
			if(LCD.getText().toString().isEmpty()) {
				Toast.makeText(MainActivity.this, "Enter a Number", Toast.LENGTH_SHORT).show();
			}else if (LCD.getText().toString().equals(".")){
				Toast.makeText(MainActivity.this, "INVALID INPUT", Toast.LENGTH_SHORT).show();
				LCD.setText(null);
			}else {
				Fnum=Float.parseFloat(LCD.getText().toString());
				LCD.setText("");
			}
		}
		
	//button subtraction
		public void Subtract(View v) {
			Operation = 2;
			
			if(LCD.getText().toString().isEmpty()) 
			{
				Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_SHORT).show();
			}else if (LCD.getText().toString().equals(".")){
				Toast.makeText(MainActivity.this, "INVALID INPUT", Toast.LENGTH_SHORT).show();
				LCD.setText(null);
			}else {
				Fnum = Float.parseFloat(LCD.getText().toString());
				LCD.setText("");
			}
		}
		
	//button multiplication
		public void Multiply(View v) {
			Operation = 3;
			
			if(LCD.getText().toString().isEmpty()) 
			{
				Toast.makeText(getApplicationContext(), "Enter a Number", Toast.LENGTH_SHORT).show();
			}else if (LCD.getText().toString().equals(".")){
				Toast.makeText(MainActivity.this, "INVALID INPUT", Toast.LENGTH_SHORT).show();
				LCD.setText(null);
			}else {
				Fnum = Float.parseFloat(LCD.getText().toString());
				LCD.setText("");
			}
		}
		
	//button division
		public void Divide(View v) {
			Operation = 4;
			
			if(LCD.getText().toString().isEmpty()) 
			{
				Toast.makeText(getApplicationContext(), "Enter a Number", Toast.LENGTH_SHORT).show();
			}else if (LCD.getText().toString().equals(".")){
				Toast.makeText(MainActivity.this, "INVALID INPUT", Toast.LENGTH_SHORT).show();
				LCD.setText(null);
			}else {
				Fnum= Float.parseFloat(LCD.getText().toString());
				LCD.setText("");
			}
		}
	
	//button equal
		public void Compute(View v) {
			if(LCD.getText().toString().isEmpty()) 
			{
				Toast.makeText(MainActivity.this, "ERROR", Toast.LENGTH_SHORT).show();
			}else if (LCD.getText().toString().equals(".")){
				Toast.makeText(MainActivity.this, "INVALID INPUT", Toast.LENGTH_SHORT).show();
				LCD.setText(null);
			}else if(LCD.getText().toString().equals(Answer + ".")) {
				Toast.makeText(MainActivity.this, "Syntax Error", Toast.LENGTH_SHORT).show();
				LCD.setText(null);
				btndeci.setClickable(isRestricted());
			}else{
				Snum=Float.parseFloat(LCD.getText().toString());
				
				switch(Operation) {
					case 1:Answer= Fnum + Snum; break;
					case 2:Answer= Fnum - Snum; break;
					case 3:Answer= Fnum * Snum; break;
					case 4:Answer= Fnum / Snum; break;
				}
				
				LCD.setText(String.valueOf(Answer));
				
				if((Answer%1)==0) {
					double a = Answer;
					Ans = (int)a;
					LCD.setText(String.valueOf(Ans));
				}
				else {
					LCD.setText(String.valueOf(Answer));
				}
				
			}
		}
}
